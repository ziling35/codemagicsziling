export const games = {
    ["forest"]: {
        levels: 22,
    }
}